"use client";
import { useRef, useMemo, useEffect } from "react";
import { Mesh } from "three";
import * as THREE from "three";
import { useConfigurator } from "@/store/configurator";

export function GlassModel() {
  const meshRef = useRef<Mesh>(null);
  const { mode, text, fontFamily, fontSize, posX, posY, imageDataUrl, imageScale } =
    useConfigurator();

  // Glass shape via LatheGeometry
  const geometry = useMemo(() => {
    const points = [
      new THREE.Vector2(0.0,  -0.72),
      new THREE.Vector2(0.26, -0.72),
      new THREE.Vector2(0.22, -0.65),
      new THREE.Vector2(0.28, -0.40),
      new THREE.Vector2(0.38,  0.00),
      new THREE.Vector2(0.40,  0.35),
      new THREE.Vector2(0.38,  0.60),
      new THREE.Vector2(0.36,  0.72),
      new THREE.Vector2(0.38,  0.72),
    ];
    return new THREE.LatheGeometry(points, 80);
  }, []);

  // Engraving canvas texture (roughnessMap: white = frosted)
  const { canvas, texture } = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = 1024;
    canvas.height = 512;
    const texture = new THREE.CanvasTexture(canvas);
    return { canvas, texture };
  }, []);

  useEffect(() => {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    const cx = canvas.width * posX;
    const cy = canvas.height * posY;

    if (mode === "text" && text.trim()) {
      ctx.save();
      ctx.fillStyle = "rgba(255,255,255,0.9)";
      ctx.font = `${fontSize}px ${fontFamily}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.shadowColor = "rgba(255,255,255,0.6)";
      ctx.shadowBlur = 12;
      ctx.fillText(text, cx, cy);
      ctx.restore();
    }

    if (mode === "image" && imageDataUrl) {
      const img = new Image();
      img.onload = () => {
        const w = canvas.width * imageScale;
        const h = (img.naturalHeight / img.naturalWidth) * w;
        ctx.save();
        ctx.globalAlpha = 0.85;
        ctx.filter = "grayscale(1) brightness(2) contrast(1.5)";
        ctx.drawImage(img, cx - w / 2, cy - h / 2, w, h);
        ctx.restore();
        texture.needsUpdate = true;
      };
      img.src = imageDataUrl;
    }

    texture.needsUpdate = true;
  }, [mode, text, fontFamily, fontSize, posX, posY, imageDataUrl, imageScale, canvas, texture]);

  return (
    <mesh ref={meshRef} geometry={geometry} castShadow receiveShadow>
      <meshPhysicalMaterial
        color={new THREE.Color(0x8fc8e8)}
        transmission={0.94}
        roughness={0.04}
        metalness={0.02}
        thickness={0.6}
        ior={1.52}
        transparent
        opacity={0.75}
        roughnessMap={texture}
        envMapIntensity={2.0}
        attenuationColor={new THREE.Color(0xc8e8ff)}
        attenuationDistance={0.8}
        side={THREE.DoubleSide}
      />
    </mesh>
  );
}
