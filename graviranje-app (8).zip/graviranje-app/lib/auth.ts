import { betterAuth } from "better-auth";
import { prismaAdapter } from "better-auth/adapters/prisma";
import { magicLink } from "better-auth/plugins";
import { Resend } from "resend";
import { prisma } from "./prisma";

const isProd = process.env.NODE_ENV === "production";

/**
 * Resend se instancira LENJO. Ranije je `new Resend(undefined)` pucao
 * jos pri ucitavanju modula, pa je i obicna provera sesije vracala 500.
 */
let resendClient: Resend | null = null;
function getResend(): Resend | null {
  const key = process.env.RESEND_API_KEY;
  if (!key) return null;
  if (!resendClient) resendClient = new Resend(key);
  return resendClient;
}

const secret = process.env.BETTER_AUTH_SECRET;
if (!secret && isProd) {
  throw new Error("BETTER_AUTH_SECRET nije postavljen.");
}
if (!secret) {
  console.warn(
    "\n[auth] BETTER_AUTH_SECRET nije postavljen — koristim dev fallback.\n" +
      "       Za produkciju generisi: openssl rand -base64 32\n"
  );
}

function magicLinkHtml(url: string): string {
  return `
    <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:32px;background:#0f111a;color:#e8e8f0;border-radius:16px;">
      <h1 style="font-size:1.5rem;margin-bottom:8px;color:#87ceeb;">Jedan klik do vaše porudžbine</h1>
      <p style="color:#9090b0;margin-bottom:32px;">Kliknite na dugme ispod da potvrdite email i završite porudžbinu.</p>
      <a href="${url}" style="display:inline-block;background:#87ceeb;color:#0f111a;padding:14px 28px;border-radius:999px;font-weight:700;text-decoration:none;letter-spacing:0.05em;">
        POTVRDITE PORUDŽBINU →
      </a>
      <p style="margin-top:32px;font-size:0.75rem;color:#555577;">Link važi 10 minuta. Ako niste vi, ignorišite ovaj email.</p>
    </div>
  `;
}

export const auth = betterAuth({
  baseURL: process.env.BETTER_AUTH_URL ?? "http://localhost:3000",
  secret: secret ?? "dev-only-insecure-secret-change-me-32chars",
  database: prismaAdapter(prisma, { provider: "postgresql" }),
  plugins: [
    magicLink({
      sendMagicLink: async ({ email, url }) => {
        const resend = getResend();

        // ── DEV bez Resend kljuca: link ide u terminal ──
        if (!resend) {
          if (isProd) {
            throw new Error("RESEND_API_KEY nije postavljen.");
          }
          console.log(
            "\n" +
              "──────────────────────────────────────────────\n" +
              "  MAGIC LINK (dev — email nije poslat)\n" +
              "  za: " + email + "\n" +
              "  " + url + "\n" +
              "──────────────────────────────────────────────\n"
          );
          return;
        }

        const { error } = await resend.emails.send({
          from: process.env.FROM_EMAIL ?? "onboarding@resend.dev",
          to: email,
          subject: "🥂 Potvrdite vašu porudžbinu — Graviranje na čašama",
          html: magicLinkHtml(url),
        });

        if (error) {
          console.error("[auth] Resend greška:", error);
          throw new Error("Slanje email-a nije uspelo.");
        }
      },
    }),
  ],
});

export type Session = typeof auth.$Infer.Session;
