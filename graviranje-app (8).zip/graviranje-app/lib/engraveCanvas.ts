/** Crtanje graviranja na 2D canvas — deljena logika za 3D teksturu. */

export const TEX_W = 2048;
export const TEX_H = 1024;

export interface DrawOptions {
  mode: "text" | "image";
  text: string;
  fontFamily: string;
  fontSize: number;
  posX: number;
  posY: number;
  imageScale: number;
  imageThreshold: number;
  imageInvert: boolean;
  engraveStrength: number;
}

/** Zrnasta struktura peskarenog stakla — bez nje graviranje izgleda kao nalepnica. */
let grainCache: HTMLCanvasElement | null = null;
function getGrain(): HTMLCanvasElement | null {
  if (grainCache) return grainCache;
  if (typeof document === "undefined") return null;

  const size = 256;
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d");
  if (!ctx) return null;

  const img = ctx.createImageData(size, size);
  for (let i = 0; i < img.data.length; i += 4) {
    const v = 150 + Math.random() * 105;
    img.data[i] = v;
    img.data[i + 1] = v;
    img.data[i + 2] = v;
    img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  grainCache = c;
  return c;
}

/** Primeni zrno na vec nacrtanu alfu (destination-in cuva oblik). */
function applyGrain(ctx: CanvasRenderingContext2D, amount: number) {
  const grain = getGrain();
  if (!grain || amount <= 0) return;
  ctx.save();
  ctx.globalCompositeOperation = "multiply";
  ctx.globalAlpha = amount;
  const pattern = ctx.createPattern(grain, "repeat");
  if (pattern) {
    ctx.fillStyle = pattern;
    ctx.fillRect(0, 0, TEX_W, TEX_H);
  }
  ctx.restore();
}

/** letterSpacing ne postoji u starijim lib.dom tipovima. */
type Ctx2D = CanvasRenderingContext2D & { letterSpacing?: string };
function setLetterSpacing(ctx: CanvasRenderingContext2D, value: string) {
  (ctx as Ctx2D).letterSpacing = value;
}

export function drawPlaceholder(ctx: CanvasRenderingContext2D) {
  ctx.clearRect(0, 0, TEX_W, TEX_H);
  ctx.save();
  ctx.setLineDash([20, 20]);
  ctx.strokeStyle = "rgba(255,255,255,0.16)";
  ctx.lineWidth = 5;
  ctx.strokeRect(TEX_W * 0.16, TEX_H * 0.26, TEX_W * 0.68, TEX_H * 0.48);
  ctx.setLineDash([]);
  ctx.fillStyle = "rgba(255,255,255,0.26)";
  ctx.font = "500 76px ui-monospace, monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  setLetterSpacing(ctx, "8px");
  ctx.fillText("VAŠ NATPIS OVDE", TEX_W / 2, TEX_H / 2);
  ctx.restore();
}

export function drawText(ctx: CanvasRenderingContext2D, o: DrawOptions) {
  const cx = TEX_W * o.posX;
  const cy = TEX_H * (1 - o.posY);
  const size = o.fontSize * 3.2;
  const s = o.engraveStrength;

  ctx.clearRect(0, 0, TEX_W, TEX_H);
  ctx.save();
  ctx.font = `600 ${size}px ${o.fontFamily}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  setLetterSpacing(ctx, `${Math.round(size * 0.04)}px`);

  // 1) Sirok mek oreol — rasejanje svetla kroz matirano staklo
  ctx.shadowColor = `rgba(200,235,255,${0.55 * s})`;
  ctx.shadowBlur = size * 0.55;
  ctx.fillStyle = `rgba(255,255,255,${0.30 * s})`;
  ctx.fillText(o.text, cx, cy);

  // 2) Uzi oreol
  ctx.shadowBlur = size * 0.18;
  ctx.fillStyle = `rgba(255,255,255,${0.45 * s})`;
  ctx.fillText(o.text, cx, cy);

  // 3) Jezgro
  ctx.shadowBlur = 0;
  ctx.fillStyle = `rgba(255,255,255,${0.95 * s})`;
  ctx.fillText(o.text, cx, cy);

  // 4) Ostra ivica — sveze urezan rub hvata svetlo
  ctx.lineWidth = Math.max(1, size * 0.012);
  ctx.strokeStyle = `rgba(255,255,255,${0.85 * s})`;
  ctx.strokeText(o.text, cx, cy);

  ctx.restore();

  applyGrain(ctx, 0.5);
}

/**
 * Slika -> efekat peskarenja.
 * Tamni pikseli postaju matirano staklo (belo, neprovidno),
 * svetli postaju providni. Prag i inverzija su korisnicki podesivi.
 */
export function drawImageEtched(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  o: DrawOptions
) {
  const cx = TEX_W * o.posX;
  const cy = TEX_H * (1 - o.posY);
  const s = o.engraveStrength;

  const w = Math.max(1, Math.round(TEX_W * o.imageScale));
  const h = Math.max(1, Math.round((img.naturalHeight / img.naturalWidth) * w));

  const off = document.createElement("canvas");
  off.width = w;
  off.height = h;
  const octx = off.getContext("2d", { willReadFrequently: true });
  if (!octx) return;
  octx.imageSmoothingQuality = "high";
  octx.drawImage(img, 0, 0, w, h);

  let data: ImageData;
  try {
    data = octx.getImageData(0, 0, w, h);
  } catch {
    ctx.clearRect(0, 0, TEX_W, TEX_H);
    ctx.drawImage(off, cx - w / 2, cy - h / 2);
    return;
  }

  const px = data.data;
  const threshold = o.imageThreshold;

  for (let i = 0; i < px.length; i += 4) {
    const a0 = px[i + 3] / 255;
    // Luminanca (Rec. 709)
    const lum = (0.2126 * px[i] + 0.7152 * px[i + 1] + 0.0722 * px[i + 2]) / 255;

    // Tamno = gravirano; invert okrece odnos
    let etch = o.imageInvert ? lum : 1 - lum;

    // Mek prag oko threshold vrednosti -> cuva polutonove
    const edge = 0.28;
    etch = (etch - (1 - threshold) + edge / 2) / edge;
    etch = Math.min(1, Math.max(0, etch));

    // Blaga gama — polutonovi lice na pravo peskarenje
    etch = Math.pow(etch, 0.85);

    px[i] = 255;
    px[i + 1] = 255;
    px[i + 2] = 255;
    px[i + 3] = Math.round(etch * a0 * 245 * s);
  }

  octx.putImageData(data, 0, 0);

  ctx.clearRect(0, 0, TEX_W, TEX_H);
  ctx.save();
  // Mek oreol ispod
  ctx.globalAlpha = 0.4 * s;
  ctx.filter = "blur(12px)";
  ctx.drawImage(off, cx - w / 2, cy - h / 2);
  // Ostra slika preko
  ctx.filter = "none";
  ctx.globalAlpha = 1;
  ctx.drawImage(off, cx - w / 2, cy - h / 2);
  ctx.restore();

  applyGrain(ctx, 0.42);
}
