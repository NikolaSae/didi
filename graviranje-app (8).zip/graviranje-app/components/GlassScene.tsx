"use client";
import { Canvas, useThree, useFrame } from "@react-three/fiber";
import {
  OrbitControls, Environment, Lightformer, ContactShadows,
  AdaptiveDpr, Preload,
} from "@react-three/drei";
import { EffectComposer, Bloom, Vignette, ChromaticAberration } from "@react-three/postprocessing";
import { BlendFunction } from "postprocessing";
import { Suspense, useRef, useEffect, useState } from "react";
import * as THREE from "three";
import { GlassModel } from "./GlassModel";
import { useConfigurator } from "@/store/configurator";
import { GLASS_PROFILES } from "@/lib/glassModels";

/**
 * Menja udaljenost kamere kad se promeni model čaše — bez remounta Canvas-a
 * (remount bi svaki put rušio i pravio novi WebGL kontekst).
 */
function CameraRig({ distance }: { distance: number }) {
  const { camera } = useThree();
  const target = useRef(distance);

  useEffect(() => {
    target.current = distance;
  }, [distance]);

  useFrame(() => {
    const current = camera.position.length();
    const next = THREE.MathUtils.lerp(current, target.current, 0.06);
    if (Math.abs(next - current) > 0.0008) {
      camera.position.setLength(next);
    }
  });

  return null;
}

/**
 * Studio okruzenje. Umesto gotovog HDRI preseta koristimo rucno postavljene
 * softbox-e — oni prave one duge vertikalne odsjaje po kojima staklo
 * izgleda kao staklo.
 */
function StudioEnvironment() {
  return (
    <Environment resolution={512} frames={1}>
      {/* Pozadinski gradijent */}
      <color attach="background" args={["#05070c"]} />

      {/* Glavni softbox — dugacka vertikalna traka desno */}
      <Lightformer
        form="rect"
        intensity={6}
        color="#ffffff"
        position={[2.5, 1.2, 1.8]}
        rotation={[0, -Math.PI / 3, 0]}
        scale={[1.4, 6, 1]}
      />
      {/* Kontra svetlo levo — hladno */}
      <Lightformer
        form="rect"
        intensity={4}
        color="#8fd0ff"
        position={[-2.8, 0.6, 1.2]}
        rotation={[0, Math.PI / 2.6, 0]}
        scale={[1, 5, 1]}
      />
      {/* Rim odozad — izvlaci obris case iz tame */}
      <Lightformer
        form="rect"
        intensity={7}
        color="#cfe9ff"
        position={[0, 1.4, -3]}
        rotation={[0, 0, 0]}
        scale={[4, 2, 1]}
      />
      {/* Odozgo — daje sjaj na obodu */}
      <Lightformer
        form="circle"
        intensity={3.5}
        color="#ffffff"
        position={[0, 4, 0]}
        rotation={[-Math.PI / 2, 0, 0]}
        scale={3}
      />
      {/* Topli akcenat — lomi hladnocu */}
      <Lightformer
        form="rect"
        intensity={2}
        color="#ffb27a"
        position={[1.5, -1.2, 2]}
        rotation={[Math.PI / 4, 0, 0]}
        scale={[2, 1, 1]}
      />
    </Environment>
  );
}

function Effects() {
  return (
    <EffectComposer multisampling={4}>
      <Bloom
        intensity={0.75}
        luminanceThreshold={0.62}
        luminanceSmoothing={0.35}
        mipmapBlur
        radius={0.7}
      />
      <ChromaticAberration
        offset={new THREE.Vector2(0.0007, 0.0007)}
        radialModulation
        modulationOffset={0.25}
        blendFunction={BlendFunction.NORMAL}
      />
      <Vignette offset={0.28} darkness={0.62} eskil={false} />
    </EffectComposer>
  );
}

export function GlassScene() {
  const glassType = useConfigurator((s) => s.glassType);
  const profile = GLASS_PROFILES[glassType];
  const dist = profile.camDistance;

  // Auto-rotacija se gasi cim korisnik uhvati čašu i vraca posle mirovanja
  const [autoRotate, setAutoRotate] = useState(true);
  const idleTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  function onInteractStart() {
    setAutoRotate(false);
    if (idleTimer.current) clearTimeout(idleTimer.current);
  }
  function onInteractEnd() {
    if (idleTimer.current) clearTimeout(idleTimer.current);
    idleTimer.current = setTimeout(() => setAutoRotate(true), 2800);
  }

  useEffect(() => {
    return () => {
      if (idleTimer.current) clearTimeout(idleTimer.current);
    };
  }, []);

  return (
    <Canvas
      camera={{ position: [0, 0.3, 2.9], fov: 38 }}
      gl={{
        antialias: true,
        alpha: true,
        powerPreference: "high-performance",
        toneMapping: THREE.ACESFilmicToneMapping,
      }}
      dpr={[1, 2]}
      shadows
      style={{ width: "100%", height: "100%" }}
    >
      <fog attach="fog" args={["#05070c", 5, 12]} />

      {/* Osnovno svetlo — Environment nosi glavninu */}
      <ambientLight intensity={0.28} />
      <spotLight
        position={[3, 5, 3]}
        angle={0.4}
        penumbra={1}
        intensity={2.2}
        castShadow
        shadow-mapSize={[1024, 1024]}
        shadow-bias={-0.0005}
      />
      <pointLight position={[-2.5, 1, -2]} intensity={1.4} color="#7fc4ff" />

      <CameraRig distance={dist} />

      <Suspense fallback={null}>
        <StudioEnvironment />
        <GlassModel />

        {/* Meka senka na podlozi */}
        <ContactShadows
          position={[0, -0.92, 0]}
          opacity={0.5}
          scale={3}
          blur={2.4}
          far={2}
          resolution={512}
          color="#000814"
        />

        {/* Refleksija case u podlozi */}
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.93, 0]} receiveShadow>
          <circleGeometry args={[3.2, 64]} />
          <meshStandardMaterial
            color="#0a0f18"
            roughness={0.35}
            metalness={0.85}
            envMapIntensity={0.7}
          />
        </mesh>

        <Effects />
        <Preload all />
      </Suspense>

      <AdaptiveDpr pixelated />

      <OrbitControls
        enablePan={false}
        enableDamping
        dampingFactor={0.06}
        rotateSpeed={0.85}
        zoomSpeed={0.7}
        minDistance={dist * 0.55}
        maxDistance={dist * 1.9}
        minPolarAngle={Math.PI / 7}
        maxPolarAngle={(Math.PI * 6) / 7}
        autoRotate={autoRotate}
        autoRotateSpeed={0.55}
        onStart={onInteractStart}
        onEnd={onInteractEnd}
        makeDefault
      />
    </Canvas>
  );
}
