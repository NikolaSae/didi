"use client";
import { useRef, useMemo, useEffect } from "react";
import { useFrame } from "@react-three/fiber";
import { MeshTransmissionMaterial } from "@react-three/drei";
import * as THREE from "three";
import { useConfigurator } from "@/store/configurator";
import { GLASS_PROFILES, buildLathe, buildLiquid } from "@/lib/glassModels";
import {
  TEX_W, TEX_H, drawPlaceholder, drawText, drawImageEtched,
} from "@/lib/engraveCanvas";

/** Luk oko case na zadatom odstojanju — koristi se za slojeve graviranja. */
function makeBand(
  e: { radiusTop: number; radiusBottom: number; height: number; y: number; arc: number },
  offset: number,
  grow = 1
) {
  const g = new THREE.CylinderGeometry(
    e.radiusTop + offset,
    e.radiusBottom + offset,
    e.height * grow,
    96, 1, true,
    -e.arc / 2, e.arc
  );
  g.translate(0, e.y, 0);
  return g;
}

export function GlassModel() {
  const {
    glassType, mode, text, fontFamily, fontSize,
    posX, posY, imageDataUrl, imageScale, imageThreshold, imageInvert,
    engraveStrength, showLiquid,
  } = useConfigurator();

  const profile = GLASS_PROFILES[glassType];
  const groupRef = useRef<THREE.Group>(null);
  const born = useRef(0);

  // ── Geometrije ─────────────────────────────────────────────────────────
  const glassGeometry = useMemo(() => buildLathe(profile), [profile]);
  const liquidGeometry = useMemo(() => buildLiquid(profile), [profile]);
  const engraveGeometry = useMemo(() => makeBand(profile.engrave, 0.004), [profile]);
  const haloGeometry = useMemo(() => makeBand(profile.engrave, 0.011, 1.06), [profile]);
  const innerGeometry = useMemo(() => makeBand(profile.engrave, -0.006), [profile]);

  const handleGeometry = useMemo(() => {
    if (!profile.handle) return null;
    const { radius, tube } = profile.handle;
    return new THREE.TorusGeometry(radius, tube, 24, 64, Math.PI * 1.25);
  }, [profile]);

  const foamGeometry = useMemo(() => {
    const f = profile.liquid.foam;
    if (!f) return null;
    const g = new THREE.CylinderGeometry(f.radius, f.radius * 0.97, f.height, 64, 1, false);
    g.translate(0, f.y, 0);
    return g;
  }, [profile]);

  // Oslobodi GPU bafere pri promeni modela
  useEffect(() => () => glassGeometry.dispose(), [glassGeometry]);
  useEffect(() => () => liquidGeometry.dispose(), [liquidGeometry]);
  useEffect(() => () => engraveGeometry.dispose(), [engraveGeometry]);
  useEffect(() => () => haloGeometry.dispose(), [haloGeometry]);
  useEffect(() => () => innerGeometry.dispose(), [innerGeometry]);
  useEffect(() => {
    if (!handleGeometry) return;
    return () => handleGeometry.dispose();
  }, [handleGeometry]);
  useEffect(() => {
    if (!foamGeometry) return;
    return () => foamGeometry.dispose();
  }, [foamGeometry]);

  // ── Canvas tekstura ────────────────────────────────────────────────────
  const { canvas, texture } = useMemo(() => {
    const c = document.createElement("canvas");
    c.width = TEX_W;
    c.height = TEX_H;
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 16;
    t.minFilter = THREE.LinearMipmapLinearFilter;
    t.magFilter = THREE.LinearFilter;
    t.generateMipmaps = true;
    return { canvas: c, texture: t };
  }, []);

  useEffect(() => () => texture.dispose(), [texture]);

  // Token sprecava da zakasneli img.onload prepise noviji crtez
  const drawToken = useRef(0);

  useEffect(() => {
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    const token = ++drawToken.current;

    const opts = {
      mode, text, fontFamily, fontSize, posX, posY,
      imageScale, imageThreshold, imageInvert, engraveStrength,
    };

    const isEmpty =
      (mode === "text" && !text.trim()) ||
      (mode === "image" && !imageDataUrl);

    if (isEmpty) {
      drawPlaceholder(ctx);
      texture.needsUpdate = true;
      return;
    }

    if (mode === "text") {
      drawText(ctx, opts);
      texture.needsUpdate = true;
      return;
    }

    if (imageDataUrl) {
      const img = new Image();
      img.onload = () => {
        if (token !== drawToken.current) return; // zastareo crtez
        drawImageEtched(ctx, img, opts);
        texture.needsUpdate = true;
      };
      img.src = imageDataUrl;
    }
  }, [
    mode, text, fontFamily, fontSize, posX, posY,
    imageDataUrl, imageScale, imageThreshold, imageInvert, engraveStrength,
    canvas, texture,
  ]);

  // ── Ulazna animacija + tiho disanje ────────────────────────────────────
  useFrame((state, delta) => {
    const g = groupRef.current;
    if (!g) return;

    born.current = Math.min(1, born.current + delta * 1.1);
    // easeOutCubic
    const e = 1 - Math.pow(1 - born.current, 3);

    const t = state.clock.elapsedTime;
    g.scale.setScalar(0.86 + 0.14 * e);
    g.position.y = (1 - e) * -0.35 + Math.sin(t * 0.6) * 0.006;
    // Blag nagib prema kursoru — cini scenu "zivom"
    g.rotation.z = THREE.MathUtils.lerp(g.rotation.z, state.pointer.x * 0.035, 0.05);
    g.rotation.x = THREE.MathUtils.lerp(g.rotation.x, -state.pointer.y * 0.02, 0.05);
  });

  const liquidColor = useMemo(
    () => new THREE.Color(profile.liquid.color),
    [profile]
  );

  return (
    <group ref={groupRef}>
      {/* ── Tecnost (iza stakla) ── */}
      {showLiquid && (
        <mesh geometry={liquidGeometry} renderOrder={0}>
          <meshPhysicalMaterial
            color={liquidColor}
            roughness={0.12}
            metalness={0}
            transmission={0.55}
            thickness={1.4}
            ior={1.34}
            attenuationColor={liquidColor}
            attenuationDistance={0.55}
            transparent
            opacity={0.94}
            envMapIntensity={1.2}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {showLiquid && foamGeometry && (
        <mesh geometry={foamGeometry} renderOrder={0}>
          <meshStandardMaterial
            color="#fdf6e6"
            roughness={0.95}
            metalness={0}
            envMapIntensity={0.6}
          />
        </mesh>
      )}

      {/* ── Staklo ── */}
      <mesh geometry={glassGeometry} castShadow renderOrder={1}>
        <MeshTransmissionMaterial
          samples={6}
          resolution={512}
          transmission={1}
          roughness={0.03}
          thickness={profile.thickness}
          ior={1.52}
          chromaticAberration={0.06}
          anisotropicBlur={0.1}
          distortion={0.12}
          distortionScale={0.25}
          temporalDistortion={0.05}
          clearcoat={1}
          clearcoatRoughness={0.03}
          attenuationColor="#dff2ff"
          attenuationDistance={2.2}
          color="#ffffff"
          background={new THREE.Color("#0a0d14")}
          side={THREE.DoubleSide}
        />
      </mesh>

      {/* ── Drška za kriglu ── */}
      {handleGeometry && profile.handle && (
        <mesh
          geometry={handleGeometry}
          position={[profile.handle.radius * 0.92, profile.handle.y, 0]}
          rotation={[0, 0, -Math.PI * 0.62]}
          castShadow
          renderOrder={1}
        >
          <meshPhysicalMaterial
            color="#eaf6ff"
            transmission={0.94}
            roughness={0.06}
            thickness={0.35}
            ior={1.5}
            clearcoat={1}
            transparent
            opacity={0.88}
            envMapIntensity={1.8}
          />
        </mesh>
      )}

      {/* ── Graviranje: 3 sloja daju utisak dubine ── */}

      {/* a) unutrasnja senka — dno ureza */}
      <mesh geometry={innerGeometry} renderOrder={2}>
        <meshBasicMaterial
          alphaMap={texture}
          color="#20303f"
          transparent
          opacity={0.5 * engraveStrength}
          side={THREE.DoubleSide}
          depthWrite={false}
        />
      </mesh>

      {/* b) glavna matirana povrsina */}
      <mesh geometry={engraveGeometry} renderOrder={3}>
        <meshStandardMaterial
          map={texture}
          alphaMap={texture}
          transparent
          opacity={0.97}
          roughness={0.92}
          metalness={0}
          side={THREE.DoubleSide}
          depthWrite={false}
          alphaTest={0.01}
          emissive={new THREE.Color("#cfeaff")}
          emissiveMap={texture}
          emissiveIntensity={0.35 + engraveStrength * 0.45}
          envMapIntensity={0.8}
        />
      </mesh>

      {/* c) spoljni oreol — rasejano svetlo, hrani bloom */}
      <mesh geometry={haloGeometry} renderOrder={4}>
        <meshBasicMaterial
          map={texture}
          alphaMap={texture}
          color="#bfe4ff"
          transparent
          opacity={0.16 * engraveStrength}
          side={THREE.DoubleSide}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </mesh>
    </group>
  );
}
